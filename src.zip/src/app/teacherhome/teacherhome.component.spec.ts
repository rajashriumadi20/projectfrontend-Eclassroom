import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherhomeComponent } from './teacherhome.component';

describe('TeacherhomeComponent', () => {
  let component: TeacherhomeComponent;
  let fixture: ComponentFixture<TeacherhomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TeacherhomeComponent]
    });
    fixture = TestBed.createComponent(TeacherhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
